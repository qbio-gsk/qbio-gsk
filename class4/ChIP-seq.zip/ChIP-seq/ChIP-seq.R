source("https://bioconductor.org/biocLite.R") 
biocLite("AnnotationDbi")
biocLite("ChIPpeakAnno")
biocLite("biomaRt")
biocLite("GenomicRanges")
biocLite("GO.db")
biocLite("TxDb.Mmusculus.UCSC.mm10.knownGene")


library(biomaRt)
library(GenomicRanges)
library(ChIPpeakAnno)
library(AnnotationDbi)


mm10 = useMart(biomart="ENSEMBL_MART_ENSEMBL", dataset="mmusculus_gene_ensembl", host="www.ensembl.org") 
TSS.mouse.mm10 = getAnnotation(mart=mm10, featureType="TSS")

bed <- read.table("//Users/osmanbeh/Documents/qBio/ChIP-seq/Oct4_peaks.narrowPeak")
oct4 = BED2RangedData(bed[,c(1:5)])
annotatedPeak.oct4= annotatePeakInBatch(oct4, AnnotationData=TSS.mouse.mm10)

annotatedPeak.oct4 <-addGeneIDs(annotatedPeak.tcell,"org.Mm.eg.db",c("symbol"))

if(require(TxDb.Mmusculus.UCSC.mm10.knownGene)){
  aCR<-assignChromosomeRegion(annotatedPeak.oct4, nucleotideLevel=FALSE, 
                              precedence=c("Promoters", "immediateDownstream", 
                                           "fiveUTRs", "threeUTRs", 
                                           "Exons", "Introns"), 
                              TxDb=TxDb.Mmusculus.UCSC.mm10.knownGene)
  barplot(aCR$percentage, ylim=c(0,90))
}

